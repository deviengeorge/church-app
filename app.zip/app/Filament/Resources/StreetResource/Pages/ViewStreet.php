<?php

namespace App\Filament\Resources\StreetResource\Pages;

use App\Filament\Resources\StreetResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewStreet extends ViewRecord
{
    protected static string $resource = StreetResource::class;
}
