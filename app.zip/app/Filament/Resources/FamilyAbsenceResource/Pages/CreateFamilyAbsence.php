<?php

namespace App\Filament\Resources\FamilyAbsenceResource\Pages;

use App\Filament\Resources\FamilyAbsenceResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFamilyAbsence extends CreateRecord
{
    protected static string $resource = FamilyAbsenceResource::class;
}
