<?php

namespace App\Filament\Resources\FamilyAbsenceReasonResource\Pages;

use App\Filament\Resources\FamilyAbsenceReasonResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFamilyAbsenceReason extends CreateRecord
{
    protected static string $resource = FamilyAbsenceReasonResource::class;
}
