<?php

return [
    "stats" => [
        "people_count" => "عدد الاشخاص",
        "families_count" => "عدد العائلات",
        "users_count" => "عدد المستخدمين",
    ]
];
