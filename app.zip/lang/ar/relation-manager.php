<?php


return [
    "members" => [
        "make_family_name" => "اجعله رب ألاسرة",
    ],
];
