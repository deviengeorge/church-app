<?php

return [
    "stats" => [
        "people_count" => "People Count",
        "families_count" => "Families Count",
        "users_count" => "Users Count",
    ]
];
