<x-filament-panels::page>
    <h1>Hello world</h1>
</x-filament-panels::page>