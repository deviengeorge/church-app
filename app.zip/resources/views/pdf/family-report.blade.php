<div>
    @livewire('family-report', ['family' => $family])
</div>