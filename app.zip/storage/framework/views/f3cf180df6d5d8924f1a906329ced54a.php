<div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('family-report', ['family' => $family]);

$__html = app('livewire')->mount($__name, $__params, 'kVPmiGc', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div><?php /**PATH /media/devo/New Volume/wadi-hof-system-laravel/resources/views/pdf/family-report.blade.php ENDPATH**/ ?>