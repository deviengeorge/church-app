<div class="fi-ta-placeholder text-sm text-gray-400 dark:text-gray-500">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /media/devo/New Volume/wadi-hof-system-laravel/vendor/filament/tables/src/../resources/views/components/columns/placeholder.blade.php ENDPATH**/ ?>