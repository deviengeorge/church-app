<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('switch-filament-language');

$__html = app('livewire')->mount($__name, $__params, 'YUxeoyf', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?><?php /**PATH /media/devo/New Volume/wadi-hof-system-laravel/storage/framework/views/6f1bf79078c6948fcba8e44322dc90d9.blade.php ENDPATH**/ ?>