<div class="pt-10">
    <main class="wrapper w-full md:max-w-5xl mx-auto px-4 space-y-5">
        <header>
            <div>
                <h1 class="text-3xl text-center font-bold text-gray-950 dark:text-white">
                    تقرير عن أسرة <?php echo e($family->name); ?>

                </h1>
            </div>
        </header>
        <section class="">
            <?php echo e($this->familyInfolist); ?>

        </section>
        <section class="">
            <?php echo e($this->table); ?>

        </section>
        <section class="flex justify-between items-center">
            <p class="text-lg">
                تمت الطباعة بواسطة
                <br />
                <span class="font-bold"><?php echo e(Auth::user()->name); ?></span>
                <br />
                <span><?php echo e(\Carbon\Carbon::now()->format("يوم d - شهر m - سنة Y")); ?></span>
            </p>

            <!--
                <div class="border-2 border-black rounded-lg py-2 px-4">
                    <p class="text-lg">رقم الاسرة: <?php echo e($family->id); ?></p>
                    <p class="text-lg">الاب الكاهن التابع لهم: <?php echo e($family->priest?->name); ?></p>
                </div>
            -->

            <?php echo QrCode::size(100)->generate(app("App\Filament\Resources\FamilyResource")::getUrl("view", ["record" => $this->family ])); ?>


        </section>
    </main>
</div><?php /**PATH /media/devo/New Volume/wadi-hof-system-laravel/resources/views/livewire/family-report.blade.php ENDPATH**/ ?>